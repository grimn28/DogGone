Purpose:
SCT program that implements a simple RC-5 transmitter.
Intended to drive an infrared LED for remote control. 


New bits are sent from within an MRT interrupt handler. The software selects pull-up or pull-down
at an SCT input pin to control the burst activation. This could have been done internally (START/STOP
the counter) as well, but was done here to be able to see the data bits.

Similar protocols can be generated with small modifications. When changing the burst frequency
(now: 36 kHz), make sure that the system clock can be divided by the product of burst frequency and
number of ticks per burst (#define's in header file). 

Input:
PIO2_8 Transmit data (enables burst if high)

Output:
PIO2_16 configured as CTOUT_0
        LED driver, high active.
        Shows bursts of a 36 kHz signal. Single 36 kHz pulses have 25% duty cycle.

 