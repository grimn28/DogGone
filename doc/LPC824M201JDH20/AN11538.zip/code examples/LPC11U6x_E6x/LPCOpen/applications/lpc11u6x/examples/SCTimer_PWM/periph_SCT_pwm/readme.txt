Purpose:
Simple SCT program using the Red State which configures the SCT as a 32 bit timer 
to generate a PWM output signal @ SCT1_OUT0

Running mode:
* Compile, Flash the program and reset.
* Default project target set to Blinky_Release (exectuing from flash)

Note:
Tested on LPC1100 LPCXpresso Board

Output:
* Every time SW1(P0_16) goes high to low increase the duty cycle.
* Every time SW2 (P0_1)goes high to low decrease the duty cycle.
* P2_16 is SCT1_OUT0
 