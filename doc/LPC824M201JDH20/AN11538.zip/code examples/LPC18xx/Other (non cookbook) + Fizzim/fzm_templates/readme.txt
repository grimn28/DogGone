This directory includes template files for the FSM designer tool

- template-split.fzm, template-split.inc: template for the SCT in split mode (2 x 16-bit timers)

- template-unified.fzm, template-unified.inc for the SCT in unified mode (1 x 32-bit timer)