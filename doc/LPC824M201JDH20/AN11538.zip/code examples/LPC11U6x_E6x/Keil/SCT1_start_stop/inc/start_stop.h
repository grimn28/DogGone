#include "nxp_lpc11u6x.h"

#define counterH_start (5000)
#define counterH_stop  (2000)

#define counterL_start (3000)
#define counterL_stop  (2500)

extern void start_stop_init(void);

/* Match register reload macro definitions */
#define reload_deactivate_L(value) LPC_SCT->MATCHREL_L[0] = value;
#define reload_activate_L(value) LPC_SCT->MATCHREL_H[0] = value;
#define reload_activate_H(value) LPC_SCT->MATCHREL_L[1] = value;
#define reload_deactivate_H(value) LPC_SCT->MATCHREL_H[1] = value;
