#ifndef __SCT_USER_H__
#define __SCT_USER_H__

#include "LPC18xx.h"

// used for split mode template
#define match_lcnt_value (100)
#define match_hcnt_value (200)

// used for unified mode template
#define match_ucnt_value (100)


#endif
