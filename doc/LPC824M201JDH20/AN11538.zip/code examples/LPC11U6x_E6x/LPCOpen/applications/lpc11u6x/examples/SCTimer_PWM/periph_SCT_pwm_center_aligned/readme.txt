Purpose:
	Use SCT0 timer to generate a center aligned PWM output signal @ SCT1_OUT0
Running mode:
* Compile, Flash the program and reset.
* Default project target set to Blinky_Release (exectuing from flash)


Output:
*	Every time SW1 goes high to low increase the duty cycle
*	Every time SW2 goes high to low decrease the duty cycle
*	SCT1_OUT0 is connected to P2_16
