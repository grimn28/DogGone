#ifndef __SCT_USER_H__
#define __SCT_USER_H__

#include "LPC18xx.h"

#define timer_tick (1000)

#define maximum_ticks (1500)

#endif
