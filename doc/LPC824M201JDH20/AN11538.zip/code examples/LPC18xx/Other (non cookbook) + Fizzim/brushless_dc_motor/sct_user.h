/*****************************************************************************
 * sct_user.h
 *
 * Project: SCT Application Example for LPC1800
 *
 * Description:
 *   Interface to auto generated SCT code.
 *----------------------------------------------------------------------------
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
 *****************************************************************************/
                  
#ifndef __SCT_USER_H__
#define __SCT_USER_H__

#define FORWARD
//#define BACKWARD
// WARNING: you need to build the proper sct_fsm.c (.fzm) file in the project build for clockwise or counterclockwise direction
// the reference file based on the fzm configuration for counterclockwise rotation is mc_brushless_dc_counterclockwise.fzm
// also need to check the array position_table in main.c, needs to match the state assignment
// alhtough the implementation does not vary in the two state machines

#include "LPC18xx.h"

    #define match1_val             (250)
    
    #define pwm_middle             (300)

    #define pwm_end                 (0)

#endif
