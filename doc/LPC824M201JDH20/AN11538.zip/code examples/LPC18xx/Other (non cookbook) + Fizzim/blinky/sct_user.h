/*****************************************************************************
 * sct_user.h
 *
 * Project: SCT Application Example for LPC1800
 *
 * Description:
 *   Interface to auto generated SCT code.
 *----------------------------------------------------------------------------
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
 *****************************************************************************/
 
#ifndef __SCT_USER_H__
#define __SCT_USER_H__

#include "LPC18xx.h"

// This is the timer setting for the match register of the L timer
// The other relevant factors for the final blinky speed is the processor clock 
// (in this example 120MHz) and the prescaler value and the number of LED's in the 
// f(blinky) =  120MHz / (prescaler * speed * nb_of_LEDs) = 120MHz/(256*65535*4) = 1.8Hz

#define speed (65535)       // max value for the 16-bit L counter


#endif
