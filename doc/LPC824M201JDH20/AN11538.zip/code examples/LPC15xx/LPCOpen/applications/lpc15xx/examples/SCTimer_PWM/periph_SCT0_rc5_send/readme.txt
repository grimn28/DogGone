/*
 * @brief SCT0 rc5 send 
 *
 * @note
 * Copyright(C) NXP Semiconductors, 2013
 * All rights reserved.
 *
 * @par
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * LPC products.  This software is supplied "AS IS" without any warranties of
 * any kind, and NXP Semiconductors and its licensor disclaim any and
 * all warranties, express or implied, including all implied warranties of
 * merchantability, fitness for a particular purpose and non-infringement of
 * intellectual property rights.  NXP Semiconductors assumes no responsibility
 * or liability for the use of the software, conveys no license or rights under any
 * patent, copyright, mask work right, or any other intellectual property rights in
 * or to any products. NXP Semiconductors reserves the right to make changes
 * in the software without notification. NXP Semiconductors also makes no
 * representation or warranty that such application will be suitable for the
 * specified use without further testing or modification.
 *
 * @par
 * Permission to use, copy, modify, and distribute this software and its
 * documentation is hereby granted, under NXP Semiconductors' and its
 * licensor's relevant copyrights in the software, without fee, provided that it
 * is used in conjunction with NXP Semiconductors microcontrollers.  This
 * copyright, permission, and disclaimer notice must appear in all copies of
 * this code.
 */

/** @defgroup EXAMPLES_PERIPH_15XX_BLINKY LPC15xx Simple blinky example
 * @ingroup EXAMPLES_PERIPH_15XX
 * <b>Example description</b><br>
 * This example (SCTx_rc5_send) uses the SCT as an RC5 transmitter intended to drive an infrared LED for remote control. 
   The lower 16-bit timer is used to generate the 36 kHz modulated pulse with 25% duty cycle. 
   A (dummy) port pin is used as an input to the SCT. The software selects pull-up or pull-down at SCT_IN0 input pin to control the burst activation. 
   The high part of the timer is used to send out the actual Manchester encoded data.
   The MRT (Multi Rate Timer) interrupt handler (MRT_IRQHandler in main.c) is used to send the 14 data bits.<br>
 * 
 * <b>Special connection requirements</b><br>
 * There are no special connection requirements for this example.<br>
 *
 * <b>Build procedures:</b><br>
 * Visit the <a href="http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides">LPCOpen quickstart guides</a>
 * to get started building LPCOpen projects.
 *
 * <b>Supported boards and board setup:</b><br>
 * @ref LPCOPEN_15XX_BOARD_LPCXPRESSO_1549<br>
 *
 * <b>Submitting LPCOpen issues:</b><br>
 * @ref LPCOPEN_COMMUNITY
 * @{
 */

/**
 * @}
 */