Purpose:
* Show simple four-channel PWM generation.
* Uses the unified 32-bit timer mode to generate single-edge aligned outputs.
* Channels can have different polarity. Demo state machine has been configured for positive pulses at SCTOUT_0/1
  and negative pulses at SCTOUT_2/3.
* SCTIN_0 is used a #ABORT input. If low, forces the outputs to their idle states, halts the timer, and generates
  an interrupt.
* An interrupt can be generated after each cycle.

Running mode:
* Compile, Flash the program and reset.
* Default project target set to Blinky_Release (executing from flash)

Note:
Tested on LPC1100 LPCXpresso Board
LPC1100 running at 48 MHz

Input:
PIO2_8 configured as CTIN_0 (#ABORT)

Output:
PIO2_16 configured as CTOUT_0, Green LED
PIO2_17 configured as CTOUT_1, Red LED
PIO2_18 configured as CTOUT_2, Yellow LED
PIO2_19 configured as CTOUT_3, Blue LED





 