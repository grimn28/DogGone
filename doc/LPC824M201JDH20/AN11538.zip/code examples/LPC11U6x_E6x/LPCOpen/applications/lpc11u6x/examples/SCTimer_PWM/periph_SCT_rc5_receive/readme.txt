Purpose:
SCT program that implements a simple RC-5 receive.
Intended to drive an infrared LED for remote control. 

Running mode:
* Compile, Flash the program and reset.
* Default project target set to Blinky_Release (executing from flash)

Note:
Tested on LPC1100 LPCXpresso Board

Similar protocols can be generated with small modifications. When changing the burst frequency
(now: 36 kHz), make sure that the system clock can be divided by the product of burst frequency and
number of ticks per burst (#define's in header file). 

Input:
receives the data transmitted 
*	TXD to P0_19 
*	RXD to P0_18


 