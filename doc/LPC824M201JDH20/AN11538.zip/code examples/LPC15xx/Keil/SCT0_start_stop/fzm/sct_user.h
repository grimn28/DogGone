#include "LPC15xx.h"

#define counterH_start (5000)
#define counterH_stop  (2000)

#define counterL_start (3000)
#define counterL_stop  (2500)
