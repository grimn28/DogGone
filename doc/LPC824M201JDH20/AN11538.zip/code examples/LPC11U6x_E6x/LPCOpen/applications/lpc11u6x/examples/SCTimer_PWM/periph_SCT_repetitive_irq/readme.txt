Purpose:
SCT program that implements SCT1 timer to generate a 10 msec timer tick (interrupt driven) 



Output:
*  1. Use SCT1 timer to generate a 10 msec timer tick (interrupt driven).
*  2. Toggle P2_16 (green LED on LPCXpresso board) every 200 msec
 