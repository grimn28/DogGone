Purpose:
Simple SCT program using Use SCT timer to generate a 100 msec toggle output @ SCT1_OUT0

Note:
Tested on LPC1100 LPCXpresso Board

Output:
 SCT1_OUT0 is at P2_16 (toggles every 100 msec)


 