/*****************************************************************************
 *   config.h:  Header file for NXP LPC18xx Family Microprocessors
 *
 *   Copyright(C) 2010, NXP Semiconductor
 *   All rights reserved.
 *
 *
******************************************************************************/
#ifndef __CONFIG_H 
#define __CONFIG_H


/*----------------------------------------------------------------------------
  Define clock sources for hardware platform
 *----------------------------------------------------------------------------*/
#define RTC_CLK         (   32768UL)    /* RTC oscillator frequency           */
#define IRC_OSC         (12000000UL)    /* Internal RC oscillator frequency   */
#define IRC_TRIM_VAL    (     0x350)    /* IRC trim value for 12MHz output    */
#define XTAL_FREQ       (12000000UL)    /* Crystal frequency                  */


#endif /* end __CONFIG_H */

