void LEDDRIVER_open(void);
void LEDDRIVER_write(uint32_t rgb);                // write frame
void LEDDRIVER_haltAfterFrame(int on);             // (de)activate HALT after next frame
void LEDDRIVER_start(void);                        // start a transmission
