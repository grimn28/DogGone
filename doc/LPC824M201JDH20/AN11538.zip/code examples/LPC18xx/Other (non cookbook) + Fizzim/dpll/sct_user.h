#ifndef __UT_USER_H__
#define __UT_USER_H__

#include "LPC18xx.h"

#define k_mod               (64-1)

#endif
