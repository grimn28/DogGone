Purpose:
	Use SCT timer to generate a two-channel double-edge controlled PWM
	intended for use as a complementary PWM pair with dead-time control

Running mode:
* Compile, Flash the program and reset.
* Default project target set to Blinky_Release (exectuing from flash)


Output:
*	P2_8  is SCT1_IN0  = PWM signal input
*	P2_16 is SCT1_OUT0 = timeout (red LED)
*	P2_17 is SCT1_OUT1 = width_error (green LED)
