Purpose:
Simple SCT program Use the match reload registers to change the duty cycle of two PWM
signals and maintain their dead-time intervals using the NORELOAD_L bit in the SCT Configuration register


Running mode:
* Compile, Flash the program and reset.
* Default project target set to Blinky_Release (exectuing from flash)


Output:
 P2_16 (SCT1_OUT0)
 P2_17 (SCT1_OUT1) 
