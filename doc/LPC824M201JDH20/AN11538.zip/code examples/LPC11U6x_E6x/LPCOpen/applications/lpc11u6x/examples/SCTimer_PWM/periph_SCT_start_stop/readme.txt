Purpose:
Simple SCT program using the Red State which configures the SCT as a 32 bit timer
Implements a start stop event 

Running mode:
* Compile, Flash the program and reset.
* Default project target set to Blinky_Release (exectuing from flash)


Output:
 -------------------------------------------------------------------------
 * Signal      Port          Signal
 * -------------------------------------------------------------------------
 * SCT1_OUT0   P2_16         COUNTER_L_RUN
 * SCT1_OUT1   P2_17         COUNTER_H_RUN
 * SCT1_OUT2   P2_18         STATE_1
 * SCT1_OUT3   P2_19         STATE_2
