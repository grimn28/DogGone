Purpose:
	Use SCT timer capture and capture control features. It implements a PWM decoder which 
	measures the duty cycle of a PWM signal and determines whether it is above (max_width) 
	or below (min_width) a specific value.The PWM signal frequency is assumed to be 10 kHz. 
	Two output signals (width_error and timeout) are included to indicate when the 10 kHz signal
	has an error or is missing.


Running mode:
* Compile, Flash the program and reset.
* Default project target set to Blinky_Release (exectuing from flash)


Output:
*	P2_8 is SCT0_IN0
*	P2_16 is SCT0_OUT0
*	P2_17 is SCT0_OUT1