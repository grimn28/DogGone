Purpose:
* Show simple four-channel PWM generation.
* Uses the unified 32-bit timer mode to generate single-edge aligned outputs.
* An interrupt can be generated after each cycle.

Running mode:
* Compile, Flash the program and reset.

Note:
Tested on LPC1100 LPCXpresso Board

Input:
PIO2_8 configured as SCT1_IN0 

Output:
PIO2_17 configured as SCT1_OUT1, 
PIO2_16 configured as SCT1_OUT0, 






 